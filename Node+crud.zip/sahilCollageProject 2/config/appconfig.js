module.exports = {
    SQL_DatabaseName: "demo_mark_test",
    SQL_UserName: "root",
    SQL_Password: "",
    Sequlize_Logging: false,
    SQL_host: "localhost",
    SQL_dialect: "mysql",
    secretkey: "secretkey",
    
    Server_Port : 5050
}